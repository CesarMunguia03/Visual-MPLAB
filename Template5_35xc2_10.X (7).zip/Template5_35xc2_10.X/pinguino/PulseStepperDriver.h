/*Basado en la librer�a stepper.h desarrollada para pinguino y modificada
 y adaptada por Ing. Mario de Jes�s Mart�nez*/

#ifndef __STEPPER_H
#define __STEPPER_H
#define PINGUINO45K50
//#include "pic18.h"
//#include "iomanager.h"
#include "typedef.h"               // u8, u16, u32

#define MAXPRESCALER     8          // max. prescaler
#define MINPRESCALER     1          // min. prescaler
#define MAXCYCLES        0x8000     // max. CPU cycles between 2 steps
#define MINCYCLES        0xFFFF     // max. CPU cycles between 2 steps


//-----------------------------------------------------------------------------------------------------------------------------
// Variable definition that depends on PIC type:
//-----------------------------------------------------------------------------------------------------------------------------
#if defined(PINGUINO1220) || defined(PINGUINO1320)
#define TotalPICpins   19
#define TotalPICports   2

#elif defined(__18f14k22)
#define TotalPICpins   19
#define TotalPICports   3

#elif  defined(PINGUINO2455) || defined(PINGUINO2550) || defined(PINGUINO25K50) || defined(CHRP3)
#define TotalPICpins   19
#define TotalPICports   3

#elif defined(PINGUINO26J50)
#define TotalPICpins   18
#define TotalPICports   3

#elif defined(PINGUINO47J53)
#define TotalPICpins   32
#define TotalPICports   5

#elif defined(PINGUINO4550) || defined(PINGUINO45K50)
#define TotalPICpins   32
#define TotalPICports   5
#define Pins_Per_Motor   3

#elif defined(FREEJALDUINO)
#define TotalPICpins   19
#define TotalPICports   3

#elif defined(PICUNO_EQUO)
#define TotalPICpins   14
#define TotalPICports   4

#endif

u8 activatedstepper[TotalPICports];
u8 steppervalues[TotalPICports];

u32 this_number_of_steps;
u16 this_steps_per_rev;
u8  this_number_of_microsteps=2;

// Variables to control several motors
s8 MotorsToAttach = -1;
//u8  this_direction1[TotalPICpins/Pins_Per_Motor];
//u16 this_steps_per_rev1[TotalPICpins/Pins_Per_Motor];
u32 this_number_of_steps1[TotalPICpins/Pins_Per_Motor];
u8 this_clocks_pins[TotalPICpins/Pins_Per_Motor];
u32 delay_ms_per_move1[TotalPICpins/Pins_Per_Motor];
u32 delay_us_per_move1[TotalPICpins/Pins_Per_Motor];
volatile u32 this_steps_left1[TotalPICpins/Pins_Per_Motor];

u32 this_delay_us_per_step;         // delay us for one step
volatile u8 _TMRH_;                 // Timer
volatile u8 _TMRL_;                 // Timer

/*	--------------------------------------------------------------------
    Prototypes
    ------------------------------------------------------------------*/
void stepper_init(u16, u8, u8, u8, u8);

#ifdef __MICROSTEPPING__
void Stepper_setMicrostep(u8);
#endif
u16 stepper_getMaxSpeed();
u16 stepper_getMinSpeed();
void stepper_setSpeed(u16);
//void Stepper_step(int, int, int);

void stepper_oneStep(u8 index);
void stepper_interrupt();
u32 getMaxNumber(u32 Num[]);
u8 IsZero();
void cpyArrays();
static void StepperPulseToggle();

typedef struct stepper stepper;

struct stepper {    
    // motor pin numbers:
    u8 DirectionPin;
    u8 EnablePin;
    u8 EnablePinState;
    u8 ClockPin;
    u8 MotorInUse;
    u8 Direction;
    u16 (*getMaxSpeed)();
    u16 (*getMinSpeed)();
    void (*setSpeed)(u16);
    void (*Step)(stepper *, s32);
    void (*DelayPerMove)(stepper *);
    void (*DelayGroup)();
    //void (*Step)(s32, stepper *s);   
};
void stepper_step(stepper *, s32);
void ClockAttach(unsigned char pin);
void ClockAttach1(unsigned char pin);
stepper _newStepper(u16, u8, u8, u8);
void ClockDetach(unsigned char pin);
void delay_per_motor(stepper *Motor);
void delay_per_group();

#endif /* __STEPPER_H */