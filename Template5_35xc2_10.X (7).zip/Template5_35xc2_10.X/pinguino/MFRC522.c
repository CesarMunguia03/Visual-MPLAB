#ifndef RFID_C
#define RFID_C
/******************************************************************************
 * Includes
 ******************************************************************************/
#include "MFRC522.h"
#include "typedef.h"               // u8, u16, u32
#include "const.h"
#include "spi.h"
//#include "spi.c"
#include "iomanager.h"
//#include "digitalp.c"               // pinmode
//#include "digitalw.c"               // digitalwrite
//#include "digitalr.c"               // digitalread
#include "oscillator.h"             // System_getPeripheralFrequency
#include "delays.h"                // Delayms
#include "../app/string.h"

/**
 * Construct RFID
 * u8 chipSelectPin RFID /ENABLE pin
 */
void PCD_RFID1(u8 chipSelectPin, u8 resetPowerDownPin)
{
	_chipSelectPin = chipSelectPin;

  pinmode(_chipSelectPin,OUTPUT, DIGITAL);			// Set digital as OUTPUT to connect it to the RFID /ENABLE pin 
  digitalwrite(_chipSelectPin, LOW); 

  _resetPowerDownPin = resetPowerDownPin;
  pinmode(_resetPowerDownPin,OUTPUT, DIGITAL);					// Set digital pin, Not Reset and Power-down
  digitalwrite(_resetPowerDownPin, HIGH);
}


void PCD_RFID2(u8 chipSelectPin, u8 resetPowerDownPin, u8 mosiPin, u8 misoPin, u8 clockPin) {
  _mosiPin = mosiPin;
  _misoPin = misoPin;
  _clockPin = clockPin;
  _chipSelectPin = chipSelectPin;
  _resetPowerDownPin = resetPowerDownPin;  

  pinmode(_resetPowerDownPin,OUTPUT, DIGITAL);					// Set digital pin, Not Reset and Power-down
  digitalwrite(_resetPowerDownPin, HIGH);
  
  pinmode(_clockPin, OUTPUT, DIGITAL);
  pinmode(_mosiPin, OUTPUT, DIGITAL);
  pinmode(_misoPin, INPUT, DIGITAL);
  
  pinmode(_chipSelectPin, OUTPUT, DIGITAL);
  digitalwrite(_chipSelectPin, LOW); 
}



void PCD_Init()
{
    BOOL hardReset = false;

	// do not select the slave yet
	digitalwrite(_chipSelectPin, HIGH);
    if (digitalread(_resetPowerDownPin) == LOW) 	// The MFRC522 chip is in power down mode.
	{		
        digitalwrite(_resetPowerDownPin, HIGH);		// Exit power down mode. This triggers a hard reset.
        // Section 8.8.2 in the datasheet says the oscillator start-up time is the start up time of the crystal + 37,74?s. Let us be generous: 50ms.
        Delayms(50);
        hardReset = true;
    }
    if (!hardReset) { // Perform a soft reset if we haven't triggered a hard reset above.
		PCD_Reset();
	}
    // Reset baud rates
	PCD_WriteRegister(TxModeReg, 0x00);
	PCD_WriteRegister(RxModeReg, 0x00);
	// Reset ModWidthReg
	PCD_WriteRegister(ModWidthReg, 0x26);

	// When communicating with a PICC we need a timeout if something goes wrong.
	// f_timer = 13.56 MHz / (2*TPreScaler+1) where TPreScaler = [TPrescaler_Hi:TPrescaler_Lo].
	// TPrescaler_Hi are the four low bits in TModeReg. TPrescaler_Lo is TPrescalerReg.
	PCD_WriteRegister(TModeReg, 0x80);			// TAuto=1; timer starts automatically at the end of the transmission in all communication modes at all speeds
	PCD_WriteRegister(TPrescalerReg, 0xA9);		// TPreScaler = TModeReg[3..0]:TPrescalerReg, ie 0x0A9 = 169 => f_timer=40kHz, ie a timer period of 25?s.
	PCD_WriteRegister(TReloadRegH, 0x03);		// Reload timer with 0x3E8 = 1000, ie 25ms before timeout.
	PCD_WriteRegister(TReloadRegL, 0xE8);
	
	PCD_WriteRegister(TxASKReg, 0x40);		// Default 0x00. Force a 100 % ASK modulation independent of the ModGsPReg register setting
	PCD_WriteRegister(ModeReg, 0x3D);		// Default 0x3F. Set the preset value for the CRC coprocessor for the CalcCRC command to 0x6363 (ISO 14443-3 part 6.2.4)
	PCD_AntennaOn();
} // End PCD_Init()

/**
 * Reads a byte from the specified register in the MFRC522 chip.
 * The interface is described in the datasheet section 8.1.2.
 */
u8 PCD_ReadRegister(u8 reg	///< The register to read from. One of the PCD_Register enums.
								) {
	u8 value;
	
	digitalwrite(_chipSelectPin, LOW);			// Select slave
	value = SPI_write(SPI1, reg | 0x80);		// MSB == 1 is for reading. LSB is not used in address. Datasheet section 8.1.2.3.
	value = SPI_write(SPI1, 0);					// Read the value back. Send 0 to stop reading.
	digitalwrite(_chipSelectPin, HIGH);			// Release slave again
	
	return value;
} // End PCD_ReadRegister()

/**
 * Reads a number of u8s from the specified register in the MFRC522 chip.
 * The interface is described in the datasheet section 8.1.2.
 */
void PCD_ReadRegister2(  u8 reg,	///< The register to read from. One of the PCD_Register enums.
                        u8 count,			///< The number of bytes to read
                        u8 *values,		///< Byte array to store the values in.
                        u8 rxAlign		///< Only bit positions rxAlign..7 in values[0] are updated.
                        ) {
	u8 value;
    
    if (count == 0) {
		return;
	}
	//Serial.print(F("Reading ")); 	Serial.print(count); Serial.println(F(" bytes from register."));
	u8 address = 0x80 | reg;				// MSB == 1 is for reading. LSB is not used in address. Datasheet section 8.1.2.3.
	u8 index = 0;							// Index in values array.
	
	digitalwrite(_chipSelectPin, LOW);		// Select slave
	count--;								// One read is performed outside of the loop
	value = SPI_write(SPI1,address);		// Tell MFRC522 which address we want to read
	if (rxAlign) {		// Only update bit positions rxAlign..7 in values[0]
		// Create bit mask for bit positions rxAlign..7
		u8 mask = (0xFF << rxAlign) & 0xFF;
		// Read value and tell that we want to read the same address again.
		value = SPI_write(SPI1,address);
		// Apply mask to both current value of values[0] and the new data in value.
		values[0] = (values[0] & ~mask) | (value & mask);
		index++;
	}
	while (index < count) {
		values[index] = SPI_write(SPI1,address);	// Read value and tell that we want to read the same address again.
		index++;
	}
	values[index] = SPI_write(SPI1,0);			// Read the final byte. Send 0 to stop reading.
	digitalwrite(_chipSelectPin, HIGH);			// Release slave again	
} // End PCD_ReadRegister()

/**
 * Writes a byte to the specified register in the MFRC522 chip.
 * The interface is described in the datasheet section 8.1.2.
 */
void PCD_WriteRegister(u8 reg,	///< The register to write to. One of the PCD_Register enums.
									u8 value	///< The value to write.
								) 
{
    u8 val;
	
	digitalwrite(_chipSelectPin, LOW);          // Select slave
	val = SPI_write(SPI1, reg&0x7E);    // MSB == 0 is for writing. LSB is not used in address. Datasheet section 8.1.2.3.
	val = SPI_write(SPI1, value);
	digitalwrite(_chipSelectPin, HIGH);         // Release slave again
} // End PCD_WriteRegister()

void PCD_WriteRegister2(u8 reg, u8 count, u8 *values)
{
    u8 val;
  digitalwrite(_chipSelectPin, LOW); /* Select SPI Chip MFRC522 */
 
  // MSB == 0 is for writing. LSB is not used in address. Datasheet section 8.1.2.3.
  val = SPI_write(SPI1, reg&0x7E);
  for (u8 index = 0; index < count; index++)
  {
    val = SPI_write(SPI1,values[index]);
  }
 
  digitalwrite(_chipSelectPin, HIGH); /* Release SPI Chip MFRC522 */
} // End PCD_WriteRegister()

/**
 * Performs a soft reset on the MFRC522 chip and waits for it to be ready again.
 */
void PCD_Reset() {
	PCD_WriteRegister(CommandReg, PCD_SoftReset);	// Issue the SoftReset command.
	// The datasheet does not mention how long the SoftRest command takes to complete.
	// But the MFRC522 might have been in soft power-down mode (triggered by bit 4 of CommandReg) 
	// Section 8.8.2 in the datasheet says the oscillator start-up time is the start up time of the crystal + 37,74?s. Let us be generous: 50ms.
	Delayms(50);
	// Wait for the PowerDown bit in CommandReg to be cleared
	while (PCD_ReadRegister(CommandReg) & (1<<4)) {
		// PCD still restarting - unlikely after waiting 50ms, but better safe than sorry.
	}
} // End PCD_Reset()

    /**
 * Turns the antenna on by enabling pins TX1 and TX2.
 * After a reset these pins are disabled.
 */
void PCD_AntennaOn() {
	u8 value = PCD_ReadRegister(TxControlReg);
	if ((value & 0x03) != 0x03) {
		PCD_WriteRegister(TxControlReg, value | 0x03);
        //mLEDGreen_off();
	}
} // End PCD_AntennaOn()

/////////////////////////////////////////////////////////////////////////////////////
// Convenience functions - does not add extra functionality
/////////////////////////////////////////////////////////////////////////////////////

/**
 * Returns true if a PICC responds to PICC_CMD_REQA.
 * Only "new" cards in state IDLE are invited. Sleeping cards in state HALT are ignored.
 * 
 * @return bool
 */
u8 PICC_IsNewCardPresent() {
	u8 bufferATQA[2];
	u8 bufferSize = sizeof(bufferATQA);

	// Reset baud rates
	PCD_WriteRegister(TxModeReg, 0x00);
	PCD_WriteRegister(RxModeReg, 0x00);
	// Reset ModWidthReg
	PCD_WriteRegister(ModWidthReg, 0x26);

	u8 result = PICC_RequestA(bufferATQA, &bufferSize);    
	//u8 result = STATUS_OK;
    //return result;
    return (result == STATUS_OK || result == STATUS_COLLISION);
} // End PICC_IsNewCardPresent()

/**
 * Clears the bits given in mask from register reg.
 */
void PCD_ClearRegisterBitMask(	u8 reg,	///< The register to update. One of the PCD_Register enums.
								u8 mask ///< The bits to clear.
									  ) {
	u8 tmp;
	tmp = PCD_ReadRegister(reg);
    mask = ~mask;
	PCD_WriteRegister(reg, tmp & (~mask));		// clear bit mask
} // End PCD_ClearRegisterBitMask()

/**
 * Sets the bits given in mask in register reg.
 */
void PCD_SetRegisterBitMask(u8 reg,	///< The register to update. One of the PCD_Register enums.
							u8 mask	///< The bits to set.
									) { 
	u8 tmp;
	tmp = PCD_ReadRegister(reg);
	PCD_WriteRegister(reg, tmp | mask);			// set bit mask
} // End PCD_SetRegisterBitMask()

/**
 * Simple wrapper around PICC_Select.
 * Returns true if a UID could be read.
 * Remember to call PICC_IsNewCardPresent(), PICC_RequestA() or PICC_WakeupA() first.
 * The read UID is available in the class variable uid.
 * 
 * @return bool
 */
BOOL PICC_ReadCardSerial() {
	u8 result = PICC_Select(&uid, 0); //&uid,
	return (result == STATUS_OK);
    //return result;
} // End 

/////////////////////////////////////////////////////////////////////////////////////
// Functions for communicating with PICCs
/////////////////////////////////////////////////////////////////////////////////////

/**
 * Executes the Transceive command.
 * CRC validation can only be done if backData and backLen are specified.
 * 
 * @return STATUS_OK on success, STATUS_??? otherwise.
 */
u8 PCD_TransceiveData(u8 *sendData,		///< Pointer to the data to transfer to the FIFO.
													u8 sendLen,		///< Number of bytes to transfer to the FIFO.
													u8 *backData,		///< nullptr or pointer to buffer if data should be read back after executing the command.
													u8 *backLen,		///< In: Max number of bytes to write to *backData. Out: The number of bytes returned.
													u8 *validBits,	///< In/Out: The number of valid bits in the last byte. 0 for 8 valid bits. Default nullptr.
													u8 rxAlign,		///< In: Defines the bit position in backData[0] for the first bit received. Default 0.
													BOOL checkCRC		///< In: True => The last two bytes of the response is assumed to be a CRC_A that must be validated.
								 ) {
	u8 waitIRq = 0x30;		// RxIRq and IdleIRq
	return PCD_CommunicateWithPICC(PCD_Transceive, waitIRq, sendData, sendLen, backData, backLen, validBits, rxAlign, checkCRC);
} // End PCD_TransceiveData()

/**
 * Transfers data to the MFRC522 FIFO, executes a command, waits for completion and transfers data 
 * back from the FIFO. CRC validation can only be done if backData and backLen are specified.
 *
 * @return STATUS_OK on success, STATUS_??? otherwise.
 */
u8 PCD_CommunicateWithPICC(	u8 command,		///< The command to execute. One of the PCD_Command enums.
                            u8 waitIRq,		///< The bits in the ComIrqReg register that signals successful completion of the command.
                            u8 *sendData,	///< Pointer to the data to transfer to the FIFO.
                            u8 sendLen,		///< Number of bytes to transfer to the FIFO.
                            u8 *backData,	///< nullptr or pointer to buffer if data should be read back after executing the command.
                            u8 *backLen,	///< In: Max number of bytes to write to *backData. Out: The number of bytes returned.
                            u8 *validBits,	///< In/Out: The number of valid bits in the last byte. 0 for 8 valid bits.
                            u8 rxAlign,		///< In: Defines the bit position in backData[0] for the first bit received. Default 0.
                            BOOL checkCRC		///< In: True => The last two bytes of the response is assumed to be a CRC_A that must be validated.
									 ) {
	// Prepare values for BitFramingReg
	u8 txLastBits = validBits ? *validBits : 0;
	u8 bitFraming = (rxAlign << 4) + txLastBits;		// RxAlign = BitFramingReg[6..4]. TxLastBits = BitFramingReg[2..0]
	
	PCD_WriteRegister(CommandReg, PCD_Idle);			// Stop any active command.
	PCD_WriteRegister(ComIrqReg, 0x7F);					// Clear all seven interrupt request bits
	PCD_WriteRegister(FIFOLevelReg, 0x80);				// FlushBuffer = 1, FIFO initialization
	PCD_WriteRegister2(FIFODataReg, sendLen, sendData);	// Write sendData to the FIFO
	PCD_WriteRegister(BitFramingReg, bitFraming);		// Bit adjustments
	PCD_WriteRegister(CommandReg, command);				// Execute the command
	if (command == PCD_Transceive) {
		PCD_SetRegisterBitMask(BitFramingReg, 0x80);	// StartSend=1, transmission of data starts
	}
	
	// Wait for the command to complete.
	// In PCD_Init() we set the TAuto flag in TModeReg. This means the timer automatically starts when the PCD stops transmitting.
	// Each iteration of the do-while-loop takes 17.86?s.
	// TODO check/modify for other architectures than Arduino Uno 16bit
	u16 i;
	for (i = 2000; i > 0; i--) {
    //for (i = 1000; i > 0; i--) {
		u8 n = PCD_ReadRegister(ComIrqReg);	// ComIrqReg[7..0] bits are: Set1 TxIRq RxIRq IdleIRq HiAlertIRq LoAlertIRq ErrIRq TimerIRq
		if (n & waitIRq) {					// One of the interrupts that signal success has been set.
			break;
		}
		if (n & 0x01) {						// Timer interrupt - nothing received in 25ms
            //mLEDGreen_off();
			return STATUS_TIMEOUT;
            
		}
	}
	// 35.7ms and nothing happend. Communication with the MFRC522 might be down.
	if (i == 0) {
        //mLEDGreen_off();
		return STATUS_TIMEOUT;        
	}
	
	// Stop now if any errors except collisions were detected.
	u8 errorRegValue = PCD_ReadRegister(ErrorReg); // ErrorReg[7..0] bits are: WrErr TempErr reserved BufferOvfl CollErr CRCErr ParityErr ProtocolErr
	if (errorRegValue & 0x13) {	 // BufferOvfl ParityErr ProtocolErr
		return STATUS_ERROR;
	}
  
	u8 _validBits = 0;
	
	// If the caller wants data back, get it from the MFRC522.
	if (backData && backLen) {
		u8 n = PCD_ReadRegister(FIFOLevelReg);	// Number of bytes in the FIFO
		if (n > *backLen) {
			return STATUS_NO_ROOM;            
		}
		*backLen = n;											// Number of bytes returned
		PCD_ReadRegister2(FIFODataReg, n, backData, rxAlign);	// Get received data from FIFO
		_validBits = PCD_ReadRegister(ControlReg) & 0x07;		// RxLastBits[2:0] indicates the number of valid bits in the last received byte. If this value is 000b, the whole byte is valid.
		if (validBits) {
			*validBits = _validBits;
		}
	}
	
	// Tell about collisions
	if (errorRegValue & 0x08) {		// CollErr
		return STATUS_COLLISION;
	}
	
	// Perform CRC_A validation if requested.
	if (backData && backLen && checkCRC) {
		// In this case a MIFARE Classic NAK is not OK.
		if (*backLen == 1 && _validBits == 4) {
			return STATUS_MIFARE_NACK;
		}
		// We need at least the CRC_A value and all 8 bits of the last byte must be received.
		if (*backLen < 2 || _validBits != 0) {
			return STATUS_CRC_WRONG;
		}
		// Verify CRC_A - do our own calculation and store the control in controlBuffer.
		u8 controlBuffer[2];
		u8 status = PCD_CalculateCRC(&backData[0], *backLen - 2, &controlBuffer[0]);
		if (status != STATUS_OK) {
			return status;
		}
		if ((backData[*backLen - 2] != controlBuffer[0]) || (backData[*backLen - 1] != controlBuffer[1])) {
			return STATUS_CRC_WRONG;
		}
	}
	
	return STATUS_OK;
} // End PCD_CommunicateWithPICC()

/**
 * Transmits a REQuest command, Type A. Invites PICCs in state IDLE to go to READY and prepare for anticollision or selection. 7 bit frame.
 * Beware: When two PICCs are in the field at the same time I often get STATUS_TIMEOUT - probably due do bad antenna design.
 * 
 * @return STATUS_OK on success, STATUS_??? otherwise.
 */
u8 PICC_RequestA(u8 *bufferATQA, ///< The buffer to store the ATQA (Answer to request) in
				 u8 *bufferSize	 ///< Buffer size, at least two bytes. Also number of bytes returned if STATUS_OK.
										) {
	return PICC_REQA_or_WUPA(PICC_CMD_REQA, bufferATQA, bufferSize);
} // End PICC_RequestA()

/**
 * Transmits a Wake-UP command, Type A. Invites PICCs in state IDLE and HALT to go to READY(*) and prepare for anticollision or selection. 7 bit frame.
 * Beware: When two PICCs are in the field at the same time I often get STATUS_TIMEOUT - probably due do bad antenna design.
 * 
 * @return STATUS_OK on success, STATUS_??? otherwise.
 */
u8 PICC_WakeupA(u8 *bufferATQA,	///< The buffer to store the ATQA (Answer to request) in
				u8 *bufferSize	///< Buffer size, at least two bytes. Also number of bytes returned if STATUS_OK.
										) {
	return PICC_REQA_or_WUPA(PICC_CMD_WUPA, bufferATQA, bufferSize);
} // End PICC_WakeupA()

/**
 * Transmits REQA or WUPA commands.
 * Beware: When two PICCs are in the field at the same time I often get STATUS_TIMEOUT - probably due do bad antenna design.
 * 
 * @return STATUS_OK on success, STATUS_??? otherwise.
 */ 
u8 PICC_REQA_or_WUPA(u8 command,     ///< The command to send - PICC_CMD_REQA or PICC_CMD_WUPA
					 u8 *bufferATQA, ///< The buffer to store the ATQA (Answer to request) in
					 u8 *bufferSize	 ///< Buffer size, at least two bytes. Also number of bytes returned if STATUS_OK.
											) {
	u8 validBits;
	u8 status;
	
	if (bufferATQA == NULL || *bufferSize < 2) {	// The ATQA response is 2 bytes long.
		return STATUS_NO_ROOM;
	}
	PCD_ClearRegisterBitMask(CollReg, 0x80);		// ValuesAfterColl=1 => Bits received after collision are cleared.
	validBits = 7;									// For REQA and WUPA we need the short frame format - transmit only 7 bits of the last (and only) byte. TxLastBits = BitFramingReg[2..0]
	status = PCD_TransceiveData(&command, 1, bufferATQA, bufferSize, &validBits, 0, false);
	if (status != STATUS_OK) {
		return status;
	}
	if (*bufferSize != 2 || validBits != 0) {		// ATQA must be exactly 16 bits.
		return STATUS_ERROR;
	}
	return STATUS_OK;
} // End PICC_REQA_or_WUPA()

/**
 * Transmits SELECT/ANTICOLLISION commands to select a single PICC.
 * Before calling this function the PICCs must be placed in the READY(*) state by calling PICC_RequestA() or PICC_WakeupA().
 * On success:
 * 		- The chosen PICC is in state ACTIVE(*) and all other PICCs have returned to state IDLE/HALT. (Figure 7 of the ISO/IEC 14443-3 draft.)
 * 		- The UID size and value of the chosen PICC is returned in *uid along with the SAK.
 * 
 * A PICC UID consists of 4, 7 or 10 bytes.
 * Only 4 bytes can be specified in a SELECT command, so for the longer UIDs two or three iterations are used:
 * 		UID size	Number of UID bytes		Cascade levels		Example of PICC
 * 		========	===================		==============		===============
 * 		single				 4						1				MIFARE Classic
 * 		double				 7						2				MIFARE Ultralight
 * 		triple				10						3				Not currently in use?
 * 
 * @return STATUS_OK on success, STATUS_??? otherwise.
 */
//Uid *uid,			///< Pointer to Uid struct. Normally output, but can also be used to supply a known UID.
    u8 PICC_Select(Uid *uid, u8 validBits		///< The number of known UID bits supplied in *uid. Normally 0. If set you must also supply uid->size.
										 ) {
	BOOL uidComplete;
	BOOL selectDone;
	BOOL useCascadeTag;
	u8 cascadeLevel = 1;
	u8 result;
	u8 count;
	u8 index;
	u8 uidIndex;					// The first index in uid->uidByte[] that is used in the current Cascade Level.
	u8 currentLevelKnownBits;		// The number of known UID bits in the current Cascade Level.
	u8 buffer[9];					// The SELECT/ANTICOLLISION commands uses a 7 byte standard frame + 2 bytes CRC_A
	u8 bufferUsed;				// The number of bytes used in the buffer, ie the number of bytes to transfer to the FIFO.
	u8 rxAlign;					// Used in BitFramingReg. Defines the bit position for the first bit received.
	u8 txLastBits;				// Used in BitFramingReg. The number of valid bits in the last transmitted byte. 
	u8 *responseBuffer;
	u8 responseLength;
	
	// Description of buffer structure:
	//		Byte 0: SEL 				Indicates the Cascade Level: PICC_CMD_SEL_CL1, PICC_CMD_SEL_CL2 or PICC_CMD_SEL_CL3
	//		Byte 1: NVB					Number of Valid Bits (in complete command, not just the UID): High nibble: complete bytes, Low nibble: Extra bits. 
	//		Byte 2: UID-data or CT		See explanation below. CT means Cascade Tag.
	//		Byte 3: UID-data
	//		Byte 4: UID-data
	//		Byte 5: UID-data
	//		Byte 6: BCC					Block Check Character - XOR of bytes 2-5
	//		Byte 7: CRC_A
	//		Byte 8: CRC_A
	// The BCC and CRC_A are only transmitted if we know all the UID bits of the current Cascade Level.
	//
	// Description of bytes 2-5: (Section 6.5.4 of the ISO/IEC 14443-3 draft: UID contents and cascade levels)
	//		UID size	Cascade level	Byte2	Byte3	Byte4	Byte5
	//		========	=============	=====	=====	=====	=====
	//		 4 bytes		1			uid0	uid1	uid2	uid3
	//		 7 bytes		1			CT		uid0	uid1	uid2
	//						2			uid3	uid4	uid5	uid6
	//		10 bytes		1			CT		uid0	uid1	uid2
	//						2			CT		uid3	uid4	uid5
	//						3			uid6	uid7	uid8	uid9
	
	// Sanity checks
	if (validBits > 80) {
		return STATUS_INVALID;
	}
	
	// Prepare MFRC522
	PCD_ClearRegisterBitMask(CollReg, 0x80);		// ValuesAfterColl=1 => Bits received after collision are cleared.
	
	// Repeat Cascade Level loop until we have a complete UID.
	uidComplete = false;
	while (!uidComplete) {
		// Set the Cascade Level in the SEL byte, find out if we need to use the Cascade Tag in byte 2.
		switch (cascadeLevel) {
			case 1:
				buffer[0] = PICC_CMD_SEL_CL1;
				uidIndex = 0;
				useCascadeTag = validBits && (uid->size > 4);	//> 4 When we know that the UID has more than 4 bytes
				break;
			
			case 2:
				buffer[0] = PICC_CMD_SEL_CL2;
				uidIndex = 3;
				useCascadeTag = validBits && (uid->size > 7);	//> 7 When we know that the UID has more than 7 bytes
				break;
			
			case 3:
				buffer[0] = PICC_CMD_SEL_CL3;
				uidIndex = 6;
				useCascadeTag = false;						// Never used in CL3.
				break;
			
			default:
				return STATUS_INTERNAL_ERROR;
				break;
		}
		
		// How many UID bits are known in this Cascade Level?
		currentLevelKnownBits = validBits - (8 * uidIndex);
		if (currentLevelKnownBits < 0) {
			currentLevelKnownBits = 0;
		}
		// Copy the known bits from uid->uidByte[] to buffer[]
		index = 2; // destination index in buffer[]
		if (useCascadeTag) {
			buffer[index++] = PICC_CMD_CT;
		}
		u8 bytesToCopy = currentLevelKnownBits / 8 + (currentLevelKnownBits % 8 ? 1 : 0); // The number of bytes needed to represent the known bits for this level.
		if (bytesToCopy) {
			u8 maxBytes = useCascadeTag ? 3 : 4; // Max 4 bytes in each Cascade Level. Only 3 left if we use the Cascade Tag
			if (bytesToCopy > maxBytes) {
				bytesToCopy = maxBytes;
			}
			for (count = 0; count < bytesToCopy; count++) {
				buffer[index++] = uid->uidByte[uidIndex + count];
			}
		}
		// Now that the data has been copied we need to include the 8 bits in CT in currentLevelKnownBits
		if (useCascadeTag) {
			currentLevelKnownBits += 8;
		}
		
		// Repeat anti collision loop until we can transmit all UID bits + BCC and receive a SAK - max 32 iterations.
		selectDone = false;
		while (!selectDone) {
			// Find out how many bits and bytes to send and receive.
			if (currentLevelKnownBits >= 32) { // All UID bits in this Cascade Level are known. This is a SELECT.
				//Serial.print(F("SELECT: currentLevelKnownBits=")); Serial.println(currentLevelKnownBits, DEC);
				buffer[1] = 0x70; // NVB - Number of Valid Bits: Seven whole bytes
				// Calculate BCC - Block Check Character
				buffer[6] = buffer[2] ^ buffer[3] ^ buffer[4] ^ buffer[5];
				// Calculate CRC_A
				result = PCD_CalculateCRC(buffer, 7, &buffer[7]);
				if (result != STATUS_OK) {
					return result;
				}
				txLastBits		= 0; // 0 => All 8 bits are valid.
				bufferUsed		= 9;
				// Store response in the last 3 bytes of buffer (BCC and CRC_A - not needed after tx)
				responseBuffer	= &buffer[6];
				responseLength	= 3;
			}
			else { // This is an ANTICOLLISION.
				//Serial.print(F("ANTICOLLISION: currentLevelKnownBits=")); Serial.println(currentLevelKnownBits, DEC);
				txLastBits		= currentLevelKnownBits % 8;
				count			= currentLevelKnownBits / 8;	// Number of whole bytes in the UID part.
				index			= 2 + count;					// Number of whole bytes: SEL + NVB + UIDs
				buffer[1]		= (index << 4) + txLastBits;	// NVB - Number of Valid Bits
				bufferUsed		= index + (txLastBits ? 1 : 0);
				// Store response in the unused part of buffer
				responseBuffer	= &buffer[index];
				responseLength	= sizeof(buffer) - index;
			}
			
			// Set bit adjustments
			rxAlign = txLastBits;											// Having a separate variable is overkill. But it makes the next line easier to read.
			PCD_WriteRegister(BitFramingReg, (rxAlign << 4) + txLastBits);	// RxAlign = BitFramingReg[6..4]. TxLastBits = BitFramingReg[2..0]
			
			// Transmit the buffer and receive the response.
			result = PCD_TransceiveData(buffer, bufferUsed, responseBuffer, &responseLength, &txLastBits, rxAlign,false);
			if (result == STATUS_COLLISION) { // More than one PICC in the field => collision.
				u8 valueOfCollReg = PCD_ReadRegister(CollReg); // CollReg[7..0] bits are: ValuesAfterColl reserved CollPosNotValid CollPos[4:0]
				if (valueOfCollReg & 0x20) { // CollPosNotValid
					return STATUS_COLLISION; // Without a valid collision position we cannot continue
				}
				u8 collisionPos = valueOfCollReg & 0x1F; // Values 0-31, 0 means bit 32.
				if (collisionPos == 0) {
					collisionPos = 32;
				}
				if (collisionPos <= currentLevelKnownBits) { // No progress - should not happen 
					return STATUS_INTERNAL_ERROR;
				}
				// Choose the PICC with the bit set.
				currentLevelKnownBits = collisionPos;
				count			= (currentLevelKnownBits - 1) % 8; // The bit to modify
				index			= 1 + (currentLevelKnownBits / 8) + (count ? 1 : 0); // First byte is index 0.
				buffer[index]	|= (1 << count);
			}
			else if (result != STATUS_OK) {
				return result;
			}
			else { // STATUS_OK
				if (currentLevelKnownBits >= 32) { // This was a SELECT.
					selectDone = true; // No more anticollision 
					// We continue below outside the while.
				}
				else { // This was an ANTICOLLISION.
					// We now have all 32 bits of the UID in this Cascade Level
					currentLevelKnownBits = 32;
					// Run loop again to do the SELECT.
				}
			}
		} // End of while (!selectDone)
		
		// We do not check the CBB - it was constructed by us above.
		
		// Copy the found UID bytes from buffer[] to uid->uidByte[]
		index			= (buffer[2] == PICC_CMD_CT) ? 3 : 2; // source index in buffer[]
		bytesToCopy		= (buffer[2] == PICC_CMD_CT) ? 3 : 4;
		for (count = 0; count < bytesToCopy; count++) {
			uid->uidByte[uidIndex + count] = buffer[index++];
		}
		
		// Check response SAK (Select Acknowledge)
		if (responseLength != 3 || txLastBits != 0) { // SAK must be exactly 24 bits (1 byte + CRC_A).
			return STATUS_ERROR;
		}
		// Verify CRC_A - do our own calculation and store the control in buffer[2..3] - those bytes are not needed anymore.
		result = PCD_CalculateCRC(responseBuffer, 1, &buffer[2]);
		if (result != STATUS_OK) {
			return result;
		}
		if ((buffer[2] != responseBuffer[1]) || (buffer[3] != responseBuffer[2])) {
			return STATUS_CRC_WRONG;
		}
		if (responseBuffer[0] & 0x04) { // Cascade bit set - UID not complete yes
			cascadeLevel++;
		}
		else {
			uidComplete = true;
			uid->sak = responseBuffer[0];
		}
	} // End of while (!uidComplete)
	
	// Set correct uid->size
	uid->size = 3 * cascadeLevel + 1;

	return STATUS_OK;
} // End PICC_Select()

/**
 * Instructs a PICC in state ACTIVE(*) to go to state HALT.
 *
 * @return STATUS_OK on success, STATUS_??? otherwise.
 */ 
u8 PICC_HaltA() {
	u8 result;
	u8 buffer[4];
	
	// Build command buffer
	buffer[0] = PICC_CMD_HLTA;
	buffer[1] = 0;
	// Calculate CRC_A
	result = PCD_CalculateCRC(buffer, 2, &buffer[2]);
	if (result != STATUS_OK) {
		return result;
	}
	
	// Send the command.
	// The standard says:
	//		If the PICC responds with any modulation during a period of 1 ms after the end of the frame containing the
	//		HLTA command, this response shall be interpreted as 'not acknowledge'.
	// We interpret that this way: Only STATUS_TIMEOUT is a success.
	result = PCD_TransceiveData(buffer, sizeof(buffer), NULL, NULL, NULL, 0, false);
	if (result == STATUS_TIMEOUT) {
		return STATUS_OK;
	}
	if (result == STATUS_OK) { // That is ironically NOT ok in this case ;-)
		return STATUS_ERROR;
	}
	return result;
} // End PICC_HaltA()

/**
 * Use the CRC coprocessor in the MFRC522 to calculate a CRC_A.
 * 
 * @return STATUS_OK on success, STATUS_??? otherwise.
 */
u8 PCD_CalculateCRC(u8 *data,		///< In: Pointer to the data to transfer to the FIFO for CRC calculation.
					u8 length,	///< In: The number of bytes to transfer.
					u8 *result	///< Out: Pointer to result buffer. Result is written to result[0..1], low byte first.
					 ) {
	PCD_WriteRegister(CommandReg, PCD_Idle);		// Stop any active command.
	PCD_WriteRegister(DivIrqReg, 0x04);				// Clear the CRCIRq interrupt request bit
	PCD_WriteRegister(FIFOLevelReg, 0x80);			// FlushBuffer = 1, FIFO initialization
	PCD_WriteRegister2(FIFODataReg, length, data);	// Write data to the FIFO
	PCD_WriteRegister(CommandReg, PCD_CalcCRC);		// Start the calculation
	
	// Wait for the CRC calculation to complete. Each iteration of the while-loop takes 17.73?s.
	// TODO check/modify for other architectures than Arduino Uno 16bit

	// Wait for the CRC calculation to complete. Each iteration of the while-loop takes 17.73us.
	for (u16 i = 10000; i > 0; i--) {
		// DivIrqReg[7..0] bits are: Set2 reserved reserved MfinActIRq reserved CRCIRq reserved reserved
		u8 n = PCD_ReadRegister(DivIrqReg);
		if (n & 0x04) {									// CRCIRq bit set - calculation done
			PCD_WriteRegister(CommandReg, PCD_Idle);	// Stop calculating CRC for new content in the FIFO.
			// Transfer the result from the registers to the result buffer
			result[0] = PCD_ReadRegister(CRCResultRegL);
			result[1] = PCD_ReadRegister(CRCResultRegH);
			return STATUS_OK;
		}
	}
	// 89ms passed and nothing happend. Communication with the MFRC522 might be down.
    //mLEDGreen_off();
    return STATUS_TIMEOUT;
} // End PCD_CalculateCRC()

//------------------------------------------------------------------
BOOL RFID_readCardSerial(){

	u8 status;
	u8 str[MAX_LEN];

	// Anti-colision, devuelva el numero de serie de tarjeta de 4 bytes
	status = RFID_anticoll(str);
	memcpy(serNum, str, 5);

	if (status == STATUS_OK) {
		return true;
	} else {
		return false;
	}

 }

/**
 *  MFRC522Anticoll -> anticoll
 *  Anti-deteccion de colisiones, la lectura del numero de serie de la tarjeta de tarjeta
 *  @param serNum - devuelve el numero de tarjeta 4 bytes de serie, los primeros 5 bytes de bytes de paridad
 *  @return retorno exitoso MI_OK
 */
u8 RFID_anticoll(u8 *serNum)
{
    u8 status;
    u8 i;
	u8 serNumCheck=0;
    u16 unLen;


    //ClearBitMask(Status2Reg, 0x08);		//TempSensclear
    //ClearBitMask(CollReg,0x80);			//ValuesAfterColl
	PCD_WriteRegister(BitFramingReg, 0x00);		//TxLastBists = BitFramingReg[2..0]

    serNum[0] = PICC_CMD_SEL_CL1;
    serNum[1] = 0x20;
    status = RFID_MFRC522ToCard(PCD_Transceive, serNum, 2, serNum, &unLen);

    if (status == STATUS_OK)
	{
		//?????? Compruebe el nÃºmero de serie de la tarjeta
		for (i=0; i<4; i++)
		{   
		 	serNumCheck ^= serNum[i];
		}
		if (serNumCheck != serNum[i])
		{   
			status = STATUS_ERROR;    
		}
    }

    //SetBitMask(CollReg, 0x80);		//ValuesAfterColl=1

    return status;
}




#endif