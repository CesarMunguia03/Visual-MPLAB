
#ifndef __PRINTF_H
#define __PRINTF_H

#include "typedef.h"
#include "../app/stdarg.h"

#define PRINTF_BUF_LEN 12		// should be enough for 32 bits

typedef void (*funcout) (u8);	// type of void foo(u8)
static funcout pputchar;		// then void pputchar(u8)
static u8 pprinti(u8 **out, u32 i, u8 islong, u8 base, u8 sign, u8 width, u8 pad, u8 separator, u8 letterbase);

static void pprintc(u8 **str, u8 c);
static int pprints(u8 **out, const u8 *string, u8 width, u8 pad);
static u8 pprintfl(u8 **out, float value, u8 width, u8 pad, u8 separator, u8 precision);
static u8 pprint(u8 **out, const u8 *format, va_list args);

static u8 pprintf(funcout func, const u8 *format, va_list args);
static u8 psprintf2(u8 *out, const u8 *format, va_list args);
static u8 psprintf(u8 *out, const u8 *format, ...);

#endif /* __PRINTF_H */