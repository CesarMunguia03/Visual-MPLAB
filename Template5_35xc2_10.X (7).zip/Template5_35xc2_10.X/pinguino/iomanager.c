/*	
    FILE:           iomanager.c
    PROJECT:		Pinguino 8
	PURPOSE:		IO management
	PROGRAMER:		Mario de Jes�s Mart�nez S�nchez
	FIRST RELEASE:	27 Dic. 2017
	LAST RELEASE:	27 Dic. 2017
 
    This library has been taken from the pinguino project 8. The original 
    library has been modified to integrate the libraries "digital.h", 
    "digitalp.c", "digitalr.c", "digitalw.c" and "digitalt.c" in a single 
    library that manages inputs and outputs of a microcontroller 
    (especially the PIC18F45K50).
    The PIC18F45K50 microcontroller has many digital inputs and outputs and has  
    25 analog inputs. The main goal of this library is to facilitate the  
    configuration of the inputs or outputs either "digital" or "analog";  
    for example, if a user wants to configure the line RA0 as an analog input,  
    he should write the following line of code:

        pinmode(RA0, INPUT, ANALOG);

    On the other hand, if a user wants the line RA0 to be a digital output, 
    he should write:

        pinmode(RA0, OUTPUT, DIGITAL);

 
    --------------------------------------------------------------------
	PROJECT:		Pinguino 8
	PURPOSE:		Digital IO management
	PROGRAMER:		R�gis Blanchot
	FIRST RELEASE:	15 Mar. 2014
	LAST RELEASE:	15 Mar. 2014
	----------------------------------------------------------------------------
	TODO : 
	----------------------------------------------------------------------------
    CHANGELOG :
        regis blanchot 15 Mar. 2014 : first release
	----------------------------------------------------------------------------
	This library is free software; you can redistribute it and/or
	modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation; either
	version 2.1 of the License, or (at your option) any later version.
	This library is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
	Lesser General Public License for more details.
	You should have received a copy of the GNU Lesser General Public
	License along with this library; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
	------------------------------------------------------------------*/

#ifndef __IOMANAGER_C__
#define __IOMANAGER_C__
#define DEFAULT		0
#define	EXTERNAL	1

#include "compiler.h"
#include "typedef.h"
#include "iomanager.h"
#include "pin.h"

#if defined(ANALOGWRITE) || defined(__PWM__)
#include "pwmclose.c"
#endif

void pinMode(u8 pin, u8 state1, u8 state2)
{pinmode(pin, state1, state2);}

u8 digitalRead(u8 pin)
{return digitalread(pin);}

void digitalWrite(u8 pin, u8 state)
{digitalwrite(pin, state);}

u16 analogRead(u8 channel)
{return analogread(channel);}

void analogWrite(u8 pin, u16 duty)
{analogwrite(pin, duty);}

void pinmode(u8 pin, u8 state1, u8 state2)
{
    switch (port[pin])
    {
        case pA:
            if (state1) TRISA = (u8)(TRISA | mask[pin]);
            else  TRISA = (u8)(TRISA & (255-mask[pin]));
            
            if (state2) ANSELA = (u8)(ANSELA | mask[pin]);
            else ANSELA = (u8)(ANSELA & (255-mask[pin]));
            break;
        case pB:
            if (state1) TRISB = (u8)(TRISB | mask[pin]);
            else TRISB = (u8)(TRISB & (255-mask[pin]));
            
            if (state2) ANSELB = (u8)(ANSELB | mask[pin]);
            else ANSELB = (u8)(ANSELB & (255-mask[pin]));
            break;
        case pC:
            if (state1) TRISC = (u8)(TRISC | mask[pin]);
            else TRISC = (u8)(TRISC & (255-mask[pin]));
            
            if (state2) ANSELC = (u8)(ANSELC | mask[pin]);
            else ANSELC = (u8)(ANSELC & (255-mask[pin]));
            break;
        #if defined(PINGUINO4455)   || defined(PINGUINO4550)  || \
            defined(PINGUINO45K50)  || defined(PINGUINO46J50) || \
            defined(PINGUINO47J53) || defined(PICUNO_EQUO)
        case pD:
            if (state1) TRISD = (u8)(TRISD | mask[pin]);
            else TRISD = (u8)(TRISD & (255-mask[pin]));
            
            if (state2) ANSELD = (u8)(ANSELD | mask[pin]);
            else ANSELD = (u8)(ANSELD & (255-mask[pin]));
            break;
        case pE:
            if (state1) TRISE = (u8)(TRISE | mask[pin]);
            else TRISE = (u8)(TRISE & (255-mask[pin]));
            
            if (state2) ANSELE = (u8)(ANSELE | mask[pin]);
            else ANSELE = (u8)(ANSELE & (255-mask[pin]));
            break;
        #endif
    }
}

u8 digitalread(u8 pin)
{
    #if defined(ANALOGWRITE) || defined(__PWM__)
    PWM_close(pin);
    #endif

    switch (port[pin])
    {
        case pA:
            return ((u8)((PORTA & mask[pin])!=0));

        case pB:
            return ((u8)((PORTB & mask[pin])!=0));

        case pC:
            return ((u8)((PORTC & mask[pin])!=0));

        #if defined(PINGUINO4455)   || defined(PINGUINO4550)  || \
            defined(PINGUINO45K50)  || defined(PINGUINO46J50) || \
            defined(PINGUINO47J53A) || defined(PICUNO_EQUO)

        case pD:
            return ((u8)((PORTD & mask[pin])!=0));

        case pE:
            return ((u8)((PORTE & mask[pin])!=0));

        #endif
    }
    return 0;
}

void digitalwrite(u8 pin, u8 state)
{
    #if defined(ANALOGWRITE) || defined(__PWM__)
    PWM_close(pin);
    #endif

    switch (port[pin])
    {
        case pA:
            if (state) LATA = (u8)(LATA | mask[pin]);
            else LATA = (u8)(LATA & (255-mask[pin]));
            break;
        case pB:
            if (state) LATB = (u8)(LATB | mask[pin]); 
            else LATB = (u8)(LATB & (255-mask[pin]));
            break;
        case pC:
            if (state) LATC = (u8)(LATC | mask[pin]);
            else LATC = (u8)(LATC & (255-mask[pin]));
            break;
        #if defined(PINGUINO4455)   || defined(PINGUINO4550)  || \
            defined(PINGUINO45K50)  || defined(PINGUINO46J50) || \
            defined(PINGUINO47J53) || defined(PICUNO_EQUO)
        case pD:
            if (state) 
                LATD = (u8)(LATD | mask[pin]); 
            else 
                LATD = (u8)(LATD & (255-mask[pin]));
            break;
        case pE:
            if (state) LATE = (u8)(LATE | mask[pin]); 
            else LATE = (u8)(LATE & (255-mask[pin]));
            break;
        #endif
    }
}

void toggle(u8 pin)
{
    u8 state;
    state = digitalread(pin);
    digitalwrite(pin, (u8)(state^1));
}

/*  --------------------------------------------------------------------
    Init
    ------------------------------------------------------------------*/

void analog_init(void)
{

    #if defined(PINGUINO1220) || defined(PINGUINO1320)

	TRISA=TRISA | 0x1F; // 0b00011111 = RA0,1,2,3,4 = AN0 to AN4 are INPUT
	ADCON1=0x1F;        // 0b00001000 = 0, 0, VRef-=VSS, VRef+=VDD, AN0 to AN4 enabled 
	ADCON2=0xBD;        // 0b10111101 = Right justified, 0, 20 TAD, FOSC/16

    #elif defined(PINGUINO4550)

	TRISA=TRISA | 0x2F;
	TRISE=TRISE | 0x07;	
	ADCON1=0x07;
	ADCON2=0xBD;

    #elif defined(PICUNO_EQUO)

	TRISA=TRISA | 0x2F;	//RA0..2, RA5
	TRISE=TRISE | 0x03;	//RE0..1
	ADCON1=0x08;		//AN0-AN6, Vref+ = VDD, RA4 as Digital o/p
	ADCON2=0xBD;		//Right justified, 20TAD, FOSC/16

    #elif defined(PINGUINO26J50)

	TRISA=TRISA | 0x2F;	// 0b00101111 = RA0,1,2,3 and RA5 = AN0 to AN4 are INPUT
    //1 = Pin configured as a digital port
    //0 = Pin configured as an analog channel � digital input is disabled and reads �0�
	ANCON0=0xE0;//0x1F; // 0b11100000 = AN0 to AN4 enabled, AN5 to AN7 disabled
	ANCON1|=0x1F;//0x0A;// 0b00111111 = AN8 to AN12 disabled (1=digital/0=analog)
	ADCON0=0x00;        // 0b00000000 = VRef-=VSS, VRef+=VDD, No channel selected yet 
	ADCON1=0xBD;		// 0b10111101 = Right justified, Calibration Normal, 20TAD, FOSC/16

    #elif defined(PINGUINO47J53)
    // RB 09/09/2013: Analog Conversion Mode is set to 12-bit in Bootloader Config file
    // #pragma config ADCSEL = BIT12 // 12-bit conversion mode is enabled

    // RB - March 2014 - Individual Analog channel selection is done in analogRead()
	//TRISA=TRISA|0b00011111;	// RA0 (AN0) to RA4 (AN4) are INPUT
	//TRISE=TRISE|0b00000111;	// RE0 (AN5) to RE2 (AN7) are INPUT

    //1 = Pin configured as a digital port
    //0 = Pin configured as an analog channel � digital input is disabled and reads �0�
    // RB - March 2014 - Individual Analog channel selection is done in analogRead()
	//ANCON0=0;           // AN0 to AN7 enabled
	ANCON1=0b01111111;  // VBGEN=0, AN8 to AN12 disabled (1=digital/0=analog)

	ADCON0=0x00;        // 0b00000000 = VRef-=VSS, VRef+=VDD, No channel selected yet 
	ADCON1=0b10111110;	// Right justified, Calibration Normal, 20TAD, FOSC/64

    #elif defined(__18f25k50) || defined(__18f45k50) 
    // RB : 01-12-2013
    //TRISA  = TRISA  | 0x2F; // 0b00101111 = RA0,1,2,3 and RA5 = AN0 to AN4 are INPUT
    //ANSELA = ANSELA | 0x2F; // AN0 to AN4 enabled 
    //ANSELB = 0;
    //ANSELC = 0;
    #if defined(__18f45k50) 
    //ANSELD = 0;
    //ANSELE = 0;
    #endif
	ADCON1 = 0x00;          // VRef-=VSS, VRef+=VDD
	//ADCON2 = 0xBD;          // 0b10111101 = Right justified, 0, 20 TAD, FOSC/16
    ADCON2 = 0b10111110;
    #else // PINGUINO2550

	TRISA=TRISA | 0x2F; // 0b00101111 = RA0,1,2,3 and RA5 = AN0 to AN4 are INPUT
	ADCON1=0x0A;        // 0b00001000 = 0, 0, VRef-=VSS, VRef+=VDD, AN0 to AN4 enabled 
	ADCON2=0xBD;        // 0b10111101 = Right justified, 0, 20 TAD, FOSC/16

    #endif
}

/*  --------------------------------------------------------------------
    analogReference
    ------------------------------------------------------------------*/

//#ifdef ANALOGREFERENCE

void analogreference(u8 Type)
{
    #if !defined(PINGUINO26J50) && !defined(PINGUINO46J50) && \
        !defined(PINGUINO27J53) && !defined(PINGUINO47J53)   

    if(Type == DEFAULT)			//the default analog reference of 5 volts (on 5V Arduino boards) or 3.3 volts (on 3.3V Arduino boards)
        ADCON1|=0x00;			//Vref+ = VDD
    else if(Type == EXTERNAL)	//the voltage applied to the AREF pin (0 to 5V only) is used as the reference.
        ADCON1|=0x10;			//Vref+ = External source

    #else

    if(Type == DEFAULT)			//the default analog reference of 5 volts (on 5V Arduino boards) or 3.3 volts (on 3.3V Arduino boards)
        ADCON0|=0x00;			//Vref+ = VDD
    else if(Type == EXTERNAL)	//the voltage applied to the AREF pin (0 to 5V only) is used as the reference.
        ADCON0|=0x40;			//Vref+ = External source

    #endif
}

//#endif /* ANALOGREFERENCE */

/*  --------------------------------------------------------------------
    analogRead
    ------------------------------------------------------------------*/

//#ifdef ANALOGREAD

// The A/D conversion requires 11 TAD per 10-bit conversion
// and 13 TAD per 12-bit conversion.

u16 analogread(u8 channel)
{
    u16 result=0;
    // #if defined(PINGUINO4550) || defined(PICUNO_EQUO)
    // ADCON1=0x07;
    // #else
    // ADCON1=0x0A;
    // #endif

    #ifdef PICUNO_EQUO

        if(channel>=14 && channel<=16)
            ADCON0=(channel-14) << 2;
        else if(channel>=17 && channel<=19)
            ADCON0=(channel-13) << 2;

    // RB - March 2014 - Enable individual Analog channel selection
    //                   Has to be done for other Pinguino
    
    #elif defined(PINGUINO47J53)

        if (channel > 15)
            return 0;

        if (channel >= 8 && channel <= 15)
            channel = channel - 8;      // A0=8 to A7=15

        if (channel < 5)
            TRISA |= 1 << channel;      // channel as INPUT

        if (channel >= 5 && channel <= 7)
            TRISE |= 1 << (channel - 5);// channel as INPUT

        ANCON0 |= 1 << channel;         // channel enabled

        ADCON0 = channel << 2;          // A0=0 to A7=7

    #else
    
        //if(channel>=13 && channel<=20)
        //    ADCON0=(channel-13) << 2;   // A0 = 13, ..., A4 = 17
        //else if(channel<=5)
        //    ADCON0 = channel << 2;      // A0 = 0, ..., A4 = 4
        ADCON0 = (u8)(channel << 2);
    #endif

    ADCON0bits.ADON=1;                  // A/D Converter module is enabled

    for (result=1;result<10;result++)   // Acquisition time
        __asm__("NOP");

    ADCON0bits.GO=1;                    // Start A/D Conversion

    while (ADCON0bits.GO);              // Wait for conversion stop

    result = (u16)(ADRESH << 8);
    result += ADRESL;

    ADCON0bits.ADON = 0;                // A/D Converter module is disabled

    return(result);
}

//#endif /* ANALOGREAD */

/*  --------------------------------------------------------------------
    analogWrite
    analogWrite() uses PWM module.
    The maximum PWM resolution (bits) for a given PWM frequency is given by the equation :
    PWM Resolution (max) = Log ( Fosc / Fpwm ) / Log ( 2 )
    If 10-bit (max) resolution is needed, then Fpwm must be <=  Fosc / 1024.
    For ex. if Fosc = 48 MHz then Fpwm must be <= 46875 Hz
    If Fosc = 48 MHz and Fpwm = 46875 Hz and Prescaler = 1, then : 
    PWM Period = 1 / Fpwm = [(PR2) + 1] � 4 � TOSC �(TMR2 Prescale Value)
    PR2 = ( Fosc / Fpwm / 4 / TMR2 Prescale Value ) - 1
    PR2 = 255
    ------------------------------------------------------------------*/

//#ifdef ANALOGWRITE

// Set the PWM period by writing to the PR2 register.
// Set the TMR2 prescale value, then enable Timer2 by writing to T2CON.
// PIC18F47J53 Family :
// The assignment of a particular timer to a module is determined by the
// Timer to CCP enable bits in the CCPTMRSx registers.
// The CCPTMRS1 register selects the timers for CCP modules, 7, 6, 5 and 4,
// and the CCPTMRS2 register selects the timers for CCP modules, 10, 9 and 8

void analogwrite_init()
{
    #if defined(__18f26j53) || defined(__18f46j53) || \
        defined(__18f27j53) || defined(__18f47j53)

    CCPTMRS0 = 0;
    CCPTMRS1 = 0;                       // assign Timer2 to all CCP pins
    CCPTMRS2 = 0;

    #endif

    PR2 = 0xFF;          // set PWM period to the max. to get 10-bit res.
    T2CON = 0b00000100;  // Timer2 on, prescaler is 1
}

void analogwrite(u8 pin, u16 duty)
{
    switch (pin)
    {

        #if defined(__18f26j53) || defined(__18f46j53) || \
            defined(__18f27j53) || defined(__18f47j53)

        /*
        On PIC18F47J53 CCPx pin are multiplexed with a PORTB data latch,
        the appropriate TRIS bit must be cleared by user to make the CCPx pin an output.
        */
        
        case CCP4:
            //BitClear(TRISB, pin);             // Make the CCPx pin an output by clearing the appropriate TRIS bit.
            CCP4CON  = 0b00001100;              // Configure the CCPx module for PWM operation
            CCPR4L   = ( duty >> 2 ) & 0xFF;    // Set the PWM duty cycle by writing to the CCPRxL register
            CCP4CON |= ((u8)duty & 0x03) << 4;  // and CCPxCON<5:4> bits
            break;

        case CCP5:
            //BitClear(TRISB, pin);             // Make the CCPx pin an output by clearing the appropriate TRIS bit.
            CCP5CON  = 0b00001100;              // Configure the CCPx module for PWM operation
            CCPR5L   = ( duty >> 2 ) & 0xFF;    // Set the PWM duty cycle by writing to the CCPRxL register
            CCP5CON |= ((u8)duty & 0x03) << 4;  // and CCPxCON<5:4> bits
            break;

        case CCP6:
            //BitClear(TRISB, pin);             // Make the CCPx pin an output by clearing the appropriate TRIS bit.
            CCP6CON  = 0b00001100;              // Configure the CCPx module for PWM operation
            CCPR6L   = ( duty >> 2 ) & 0xFF;    // Set the PWM duty cycle by writing to the CCPRxL register
            CCP6CON |= ((u8)duty & 0x03) << 4;  // and CCPxCON<5:4> bits
            break;

        case CCP7:
            //BitClear(TRISB, pin);             // Make the CCPx pin an output by clearing the appropriate TRIS bit.
            CCP7CON  = 0b00001100;              // Configure the CCPx module for PWM operation
            CCPR7L   = ( duty >> 2 ) & 0xFF;    // Set the PWM duty cycle by writing to the CCPRxL register
            CCP7CON |= ((u8)duty & 0x03) << 4;  // and CCPxCON<5:4> bits
            break;

        case CCP8:
            //BitClear(TRISB, pin);             // Make the CCPx pin an output by clearing the appropriate TRIS bit.
            CCP8CON  = 0b00001100;              // Configure the CCPx module for PWM operation
            CCPR8L   = ( duty >> 2 ) & 0xFF;    // Set the PWM duty cycle by writing to the CCPRxL register
            CCP8CON |= ((u8)duty & 0x03) << 4;  // and CCPxCON<5:4> bits
            break;

        case CCP9:
            //BitClear(TRISB, pin);             // Make the CCPx pin an output by clearing the appropriate TRIS bit.
            CCP9CON  = 0b00001100;              // Configure the CCPx module for PWM operation
            CCPR9L   = ( duty >> 2 ) & 0xFF;    // Set the PWM duty cycle by writing to the CCPRxL register
            CCP9CON |= ((u8)duty & 0x03) << 4;  // and CCPxCON<5:4> bits
            break;

        case CCP10:
            //BitClear(TRISB, pin);             // Make the CCPx pin an output by clearing the appropriate TRIS bit.
            CCP10CON  = 0b00001100;             // Configure the CCPx module for PWM operation
            CCPR10L   = ( duty >> 2 ) & 0xFF;   // Set the PWM duty cycle by writing to the CCPRxL register
            CCP10CON |= ((u8)duty & 0x03) << 4; // and CCPxCON<5:4> bits
            break;

        #else

        case CCP1:
            CCP1CON  = 0b00001100;
            CCPR1L   = ( duty >> 2 ) & 0xFF;    // 8 LSB
            CCP1CON |= (u8)(((u8)duty & 0x03) << 4);  // 2 MSB in <5:4>
            break;

        case CCP2:
            CCP2CON  = 0b00001100;
            CCPR2L   = ( duty >> 2 ) & 0xFF;    // 8 LSB
            CCP2CON |= (u8)(((u8)duty & 0x03) << 4);  // 2 MSB in <5:4>
            break;

        #endif

    }

    PIR1bits.TMR2IF = 0;
}


#endif /* __IOMANAGER_C__ */