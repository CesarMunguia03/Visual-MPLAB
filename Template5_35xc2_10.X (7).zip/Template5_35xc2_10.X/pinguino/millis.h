#ifndef _MILLIS_H_
#define _MILLIS_H_
#include "typedef.h"

volatile u32 _millis;
volatile u32 _PR0_;

void updateMillisReloadValue(void);
void millis_init(void);
u32 millis();
void millis_interrupt(void);

#endif /* _MILLIS_H_ */