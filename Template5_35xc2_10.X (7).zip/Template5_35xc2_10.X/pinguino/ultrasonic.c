#ifndef __ULTRASONIC_C
#define __ULTRASONIC_C

#include "pic18.h"
#include "const.h"
#include "typedef.h"
#include "iomanager.h"
#include "ultrasonic.h"
#include "delays.h"
#include "pulseWidth.h"

void Ultrasonic(u8 TP, u8 EP)
{
    Trig_pin = TP;
    Echo_pin = EP;
    pinmode(TP, OUTPUT, DIGITAL);
    pinmode(EP, INPUT, DIGITAL);
    Time_out = 3000;  // 3000 �s = 50cm // 30000 �s = 5 m 
    //Timer 0 is config
    //Timer0 is stop, 16bits, Clock Source = FOSC/4, Prescaler =1:8
    T0CON = 0b00000010;
    T0CONbits.TMR0ON = 1;
}

void Ultrasonic1(u8 TP, u8 EP, u32 TO)
{
   pinmode(TP, OUTPUT, DIGITAL);
   pinmode(EP, INPUT, DIGITAL);
   Trig_pin = TP;
   Echo_pin = EP;
   Time_out = TO;
   //Timer 0 is config
    //Timer0 is stop, 16bits, Clock Source = FOSC/4, Prescaler =1:8
    T0CON = 0b00000010;
    T0CONbits.TMR0ON = 1;
}

u16 UltrasonicTiming(u8 EchoPin)
{
  digitalwrite(TriggerPin[EchoPin], LOW);
  Delayus(2);
  digitalwrite(TriggerPin[EchoPin], HIGH);
  Delayus(10);
  digitalwrite(TriggerPin[EchoPin], LOW);
  duration = pulseIn(EchoPin,HIGH,Time_out);
  
  if ( duration == 0 )
	duration = Time_out;
  
  return duration;
}

float UltrasonicRanging(u8 EchoPin, u8 sys)
{
  UltrasonicTiming(EchoPin);
  if (sys) {
	distance_cm = duration + 11.4497;
    distance_cm = distance_cm / 57.3283;
	return distance_cm;
  } 
  else {
	distance_cm = duration + 11.4497;
    distance_cm = distance_cm / 57.3283;
	distance_inch = distance_cm * 0.393701;
    return distance_inch; 
  }
}

void UltrasonicAttach(u8 TP, u8 EP)
{
   Time_out = 3000;  // 3000 �s = 50cm // 30000 �s = 5 m 
    
    if(EP>=TotalPICpins) return;

    switch (port[EP])
    {
        case pA: 
                TriggerPin[EP] = TP;
                UltrasonicPins[pA] = UltrasonicPins[pA] | mask[EP];  // list pin as servo driver.
                TRISA = TRISA | mask[EP]; 					// set as inoutput pin
                break;
        case pB: 
                TriggerPin[EP] = TP;
                UltrasonicPins[pB] = UltrasonicPins[pB] | mask[EP];  // list pin as servo driver.
                TRISB = TRISB | mask[EP]; 					// set as inoutput pin
                break;
        #if defined(__18f14k22) || defined(PINGUINO2455) || defined(PINGUINO2550) || defined(PINGUINO25K50) || defined(CHRP3) || defined(PINGUINO26J50) || defined(FREEJALDUINO) || defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)
        case pC: 
                TriggerPin[EP] = TP;
                UltrasonicPins[pC] = UltrasonicPins[pC] | mask[EP];  // list pin as servo driver.
                TRISC = TRISC | mask[EP]; 					// set as inoutput pin
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)				    
        case pD: 
                TriggerPin[EP] = TP;
                UltrasonicPins[pD] = UltrasonicPins[pD] | mask[EP];  // list pin as servo driver.
                TRISD = TRISD | mask[EP]; 					// set as inoutput pin
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50)	    
        case pE: 
                TriggerPin[EP] = TP;
                UltrasonicPins[pE] = UltrasonicPins[pE] | mask[EP];  // list pin as servo driver.
                TRISE = TRISE | mask[EP]; 					// set as inoutput pin
                break;	            	            
        #endif
    }
    
    if(TP>=TotalPICpins) return;

    switch (port[TP])
    {
        case pA: 
                UltrasonicPins[pA] = UltrasonicPins[pA] | mask[TP];  // list pin as servo driver.
                TRISA = TRISA & (~mask[TP]); 					// set as output pin
                break;
        case pB: 
                UltrasonicPins[pB] = UltrasonicPins[pB] | mask[TP];  // list pin as servo driver.
                TRISB = TRISB & (~mask[TP]); 					// set as output pin
                break;
        #if defined(__18f14k22) || defined(PINGUINO2455) || defined(PINGUINO2550) || defined(PINGUINO25K50) || defined(CHRP3) || defined(PINGUINO26J50) || defined(FREEJALDUINO) || defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)
        case pC: 
                UltrasonicPins[pC] = UltrasonicPins[pC] | mask[TP];  // list pin as servo driver.
                TRISC = TRISC & (~mask[TP]); 					// set as output pin
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)				    
        case pD: 
                UltrasonicPins[pD] = UltrasonicPins[pD] | mask[TP];  // list pin as servo driver.
                TRISD = TRISD & (~mask[TP]); 					// set as output pin
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50)	    
        case pE: 
                UltrasonicPins[pE] = UltrasonicPins[pE] | mask[TP];  // list pin as servo driver.
                TRISE = TRISE & (~mask[TP]); 					// set as output pin
                break;	            	            
        #endif
    }
    //Timer 0 is config
    //Timer0 is stop, 16bits, Clock Source = FOSC/4, Prescaler =1:8
    T0CON = 0b00000010;
    T0CONbits.TMR0ON = 1;
}

#endif
