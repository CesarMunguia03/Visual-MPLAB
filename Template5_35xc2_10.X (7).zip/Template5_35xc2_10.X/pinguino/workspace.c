/*	----------------------------------------------------------------------------
    workspace.h
    Mario de Jes�s Mart�nez S�nchez
    ----------------------------------------------------------------------------
*/

#ifndef __WORKSPACE_C
#define __WORKSPACE_C
#include "../app/string.h"
#include "../app/stdlib.h"
#include "../app/debug.h"
#include "const.h"
#include "typedef.h"
#include "iomanager.h"
#include "delays.h"
#include "pin.h"
//#include "mathlib.h"
//#include "spi.h"
//#include "ultrasonic.h"
//#include "servos.h"
//#include "MFRC522.h"
//#include "ds18b20.h"
//#define ONE_WIRE_BUS	RA0   // DQ line
int BeCero = B0;
int BeUno = B1; 
int BeDos = B2;
int DeCero = D0;
int DeUno = D1; 
int DeDos = D2; 
void setup()
{        
    pinMode(BeCero, DIGITAL, INPUT);
    pinMode(BeUno, DIGITAL, INPUT);
    pinMode(BeDos, DIGITAL, INPUT);
    pinMode(DeCero, DIGITAL, OUTPUT);
    pinMode(DeUno, DIGITAL, OUTPUT);
    pinMode(DeDos, DIGITAL, OUTPUT);
    //*************************************//
/*
    INTCON2bits.nRBPU = 0;     
    WPUBbits.WPUB0 = 1;
    WPUBbits.WPUB1 = 1;
    WPUBbits.WPUB2 = 1;
    WPUBbits.WPUB3 = 1;
   */ 
}

void loop()
{
    if(BeCero == HIGH){
        digitalWrite(DeCero, HIGH);
    }
     delay(200);
}

#endif