/*Basado en la librer�a stepper.c desarrollada para pinguino y modificada
 y adaptada por Ing. Mario de Jes�s Mart�nez*/
#ifndef __STEPPER_C
#define __STEPPER_C

#include "pic18.h"
#include "typedef.h"               // u8, u16, u32
#include "const.h"
#include "macro.h"                 // BitRead, high8, low8
#include "iomanager.h"
#include "oscillator.h"             // System_getPeripheralFrequency
#include "delays.h"                // Delayms
#include "PulseStepperDriver.h"
#include "delays.h"
/** --------------------------------------------------------------------
    Returns the max. speed possible (rev. per minute)
    Max. speed when time between 2 steps is minimal : 
    * prescaler = MINPRESCALER
    * cycles = MINCYCLES
    -----------------------------------------------------------------**/
u16 stepper_getMaxSpeed()
{
    return (60 * System_getPeripheralFrequency() / this_number_of_steps / MINCYCLES / MINPRESCALER);
}

/** --------------------------------------------------------------------
    Returns the min. speed possible (rev. per minute)
    Min. speed when time between 2 steps is maximal : 
    * prescaler = MAXPRESCALER
    * cycles = MAXCYCLES
    -----------------------------------------------------------------**/
u16 stepper_getMinSpeed()
{
    return (60 * System_getPeripheralFrequency() / this_number_of_steps / MAXCYCLES / MAXPRESCALER);
}

/**--------------------------------------------------------------------
    Sets the speed in revs per minute
    * ex1 : Stepper.setSpeed(60);
    * 60 revs <=> 1 min.
    * 1 rev.  <=> 1 sec. = 1000000 us
    * if Stepper = 200 steps per revolution
    * 1 step <=> 1000000/200 us = 5000 us
    * if Fosc = 48MHz, then Fcpu = Fosc / 4 = 12 MHz = 12 000 000 Hz
    * 1 cpu cycle = 1 / 12 000 000 sec. = 1/12 us
    * 1 step <=> (5000 * 12) cycles = 60000 cycles
    * Interrupt must be triggered every 60000 cycles
    * ex2 : Stepper.setSpeed(10);
    * 10 revs <=> 1 min.
    * 1 rev.  <=> 10 sec. = 10000000 us
    * if Stepper = 48 steps per revolution
    * 1 step <=> 10000000/48 us = 208333 us
    * if Fosc = 48MHz, then Fcpu = Fosc / 4 = 12 MHz = 12 000 000 Hz
    * 1 cpu cycle = 1 / 12 000 000 sec. = 1/12 us
    * 1 step <=> (208333 * 12) cycles = 2500000 cycles
    * Interrupt must be triggered every 2500000 cycles
    -----------------------------------------------------------------**/
void stepper_setSpeed(u16 revolutionPerMinute)
{
    //u32 delay_us_per_step;              // delay between 2 steps
    u32 nb_cycles_per_us;               // number of cycles per us
    u32 cycles_per_step;                // CPU cycles between 2 steps
    u8  prescaler = 0;
    
    // 0 = 00 = 1:1 Prescale value
    // 1 = 01 = 1:2 Prescale value
    // 2 = 10 = 1:4 Prescale value
    // 3 = 11 = 1:8 Prescale value

    // number of cycles during 1 us
    nb_cycles_per_us = System_getPeripheralFrequency() / 1000000UL;

    // delay between 2 steps (1 min = 60 * 1000 * 1000 us)
    this_delay_us_per_step = 60000000UL / revolutionPerMinute / this_number_of_steps;

    // number of CPU cycles between 2 steps
    cycles_per_step = this_delay_us_per_step * nb_cycles_per_us;
    
    //Se agreg� para dividir entre dos el tiempo del TMR3 para lograr
    //un flanco de bajada entre cada interrupci�n
    cycles_per_step >>= 1;
    while ( (cycles_per_step > 0xFFFF) && (prescaler < 4) )
    {
        cycles_per_step >>= 1; // /= 2;
        prescaler = prescaler + 1;
    }

    if (cycles_per_step >= 0xFFFF)
    {
        _TMRH_ = 0;
        _TMRL_ = 0;
    }
    else
    {
        _TMRH_ = highByte(0xFFFF - cycles_per_step);
        _TMRL_ =  lowByte(0xFFFF - cycles_per_step);
    }
    
    // stops interrupt
    INTCONbits.GIEH = 0;    // disable global HP interrupts
    INTCONbits.GIEL = 0;    // disable global LP interrupts

    // config. interrut
    #if defined(__18f26j50) || defined(__18f46j50) || \
        defined(__18f25k50) || defined(__18f45k50)
    T3GCONbits.TMR3GE = 0;  // disable timer gate
    #endif
    IPR2bits.TMR3IP = 0;    // interrupt has low priority
    PIR2bits.TMR3IF = 0;    // reset interrupt flag

    TMR3H = _TMRH_;         // load timer registers
    TMR3L = _TMRL_;

    T3CON = 0;
    T3CONbits.TMR3CS = 0;   // clock source is Fosc/4
    T3CONbits.T3CKPS = prescaler;// << 4; // bit 5-4 TxCKPS = prescaler
    T3CONbits.RD16 = 0;     // enables register r/w in two 8-bit operation

    // starts interrupt
    T3CONbits.TMR3ON = 1;   // Timer3 ON;
    PIE2bits.TMR3IE = 1;    // enable interrupt 
    INTCONbits.GIEL = 1;    // enable global LP interrupts
    INTCONbits.GIEH = 1;    // enable global HP interrupts
}

/**--------------------------------------------------------------------
    Moves the motor of steps_to_move steps.
    If the number is negative, the motor moves in the reverse direction.
    -----------------------------------------------------------------**/

void stepper_step(stepper *Motor, s32 steps_to_move)
{
    //u32 delay_ms_per_move;
    steps_to_move *= 2;
    //u32 this_step_to_use;
    // wait until previous command is finished
    //while (this_steps_left1 > 0 | this_steps_left2 > 0 | this_steps_left3 > 0);
    //Motor->motor_clock_pin
    digitalwrite(Motor->EnablePin, Motor->EnablePinState);
    //digitalwrite(-->EnabledPin, -->EnablePinState);
    // determine direction based on whether steps_to_move is + or -:    
    if (steps_to_move > 0) 
    {
        Motor->Direction = 1; 
        digitalwrite(Motor->DirectionPin, HIGH);
    }
    else                    
    {
        Motor->Direction = 0; 
        digitalwrite(Motor->DirectionPin, LOW);
    }
    
    // how many steps to take ?
    this_steps_left1[Motor->MotorInUse] = steps_to_move > 0 ? steps_to_move : -steps_to_move;
    
    // wait until all steps have been processed
    //delay_ms_per_move1[Motor->MotorInUse] = ( this_steps_left1[Motor->MotorInUse] * this_delay_us_per_step ) / 2; // / 1000 / 2;
    //delay_us_per_move1[Motor->MotorInUse] = delay_ms_per_move1[Motor->MotorInUse] - (( delay_ms_per_move1[Motor->MotorInUse] / 1000 ) * 1000);
    //delay_ms_per_move1[Motor->MotorInUse] = delay_ms_per_move1[Motor->MotorInUse] / 1000;
    //Motor->DelayPerMove = delay_ms_per_move1[Motor->MotorInUse];
    //Motor->DelayGroup = getMaxNumber(delay_ms_per_move1);
    //if(Motor->MotorInUse == MotorsToAttach)
        //cpyArrays();
    ClockAttach1(Motor->ClockPin);
    //return Motor;
}

static void stepper_oneStep(u8 index)
{
    u8 ToggleClockState;    
    
    ToggleClockState = !(digitalread(this_clocks_pins[index]));
    digitalwrite(this_clocks_pins[index], ToggleClockState);
}

static void Steppers_oneStep()
{
    PORTA = steppervalues[pA] ^ PORTA;
    PORTB = steppervalues[pB] ^ PORTB;
    #if defined(__18f14k22) || defined(PINGUINO2455) || defined(PINGUINO2550) || defined(PINGUINO25K50) || defined(CHRP3) || defined(PINGUINO26J50) || defined(FREEJALDUINO) || defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)
    PORTC = steppervalues[pC] ^ PORTC;
    #endif
    #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO) 
    PORTD = steppervalues[pD] ^ PORTD;
    #endif
    #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50)	    
    PORTE = steppervalues[pE] ^ PORTE;
    #endif
}
/*  --------------------------------------------------------------------
    stepper_interrupt
    called from main.c
    --------------------------------------------------------------------
    millis  uses Timer0
    servos  uses Timer1
    pwm     uses Timer2
    dcf77   uses Timer3
    stepper uses Timer3
    ------------------------------------------------------------------*/
void stepper_interrupt()
{
    // check if the timer has overflowed
    if (PIR2bits.TMR3IF)
    {
        PIR2bits.TMR3IF = 0;
        // load the timer again for the next interrupt
        TMR3H = _TMRH_;
        TMR3L = _TMRL_;
        /*
        for(u8 i = 0; i <= MotorsToAttach; i++)
        {
            // If there are still steps to move (Motor1)
            if (this_steps_left1[i]) // > 0
            {                
                stepper_oneStep(i);

                // One down so decrement the steps left
                this_steps_left1[i] -= 1;
            }            
        }
        */
        if(!IsZero())
        {
            StepperPulseToggle();
            for(u8 i = 0; i <= MotorsToAttach; i++)
            {
                // If there are still steps to move (Motor1)
                if (this_steps_left1[i]) 
                {                    
                    // One down so decrement the steps left
                    this_steps_left1[i] -= 1;
                    if(this_steps_left1[i] == 0)
                        ClockDetach(this_clocks_pins[i]);}
            }            
        }
        
        /*if (!this_steps_left1 && !this_steps_left2 && !this_steps_left3)
        {
            T3CONbits.TMR3ON = 0;   // Timer3 OFF;
            digitalwrite(this_motor1_enable_pin, LOW);
            digitalwrite(this_motor2_enable_pin, LOW);
            digitalwrite(this_motor3_enable_pin, LOW);
            
            digitalwrite(this_motor1_step_mode, LOW);
            digitalwrite(this_motor1_dir_pin, LOW);
            digitalwrite(this_motor1_clock_pin, LOW);
            
            digitalwrite(this_motor2_step_mode, LOW);
            digitalwrite(this_motor2_dir_pin, LOW);
            digitalwrite(this_motor2_clock_pin, LOW);
            
            digitalwrite(this_motor3_step_mode, LOW);
            digitalwrite(this_motor3_dir_pin, LOW);
            digitalwrite(this_motor3_clock_pin, LOW);
        }*/
    }
}

void ClockAttach(unsigned char pin)
{
    if(pin>=TotalPICpins) return;

    switch (port[pin])
    {
        case pA: 
                activatedstepper[pA] = activatedstepper[pA] | mask[pin];  // list pin as servo driver.
                break;
        case pB: 
                activatedstepper[pB] = activatedstepper[pB] | mask[pin];  // list pin as servo driver.
                break;
        #if defined(__18f14k22) || defined(PINGUINO2455) || defined(PINGUINO2550) || defined(PINGUINO25K50) || defined(CHRP3) || defined(PINGUINO26J50) || defined(FREEJALDUINO) || defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)
        case pC: 
                activatedstepper[pC] = activatedstepper[pC] | mask[pin];  // list pin as servo driver.
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)				    
        case pD: 
                activatedstepper[pD] = activatedstepper[pD] | mask[pin];  // list pin as servo driver.
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50)	    
        case pE: 
                activatedstepper[pE] = activatedstepper[pE] | mask[pin];  // list pin as servo driver.
                break;	            	            
        #endif
    }
}


void ClockAttach1(unsigned char pin)
{
    if(pin>=TotalPICpins) return;

    switch (port[pin])
    {
        case pA: 
                steppervalues[pA] = steppervalues[pA] | mask[pin];  // list pin as servo driver.
                break;
        case pB: 
                steppervalues[pB] = steppervalues[pB] | mask[pin];  // list pin as servo driver.
                break;
        #if defined(__18f14k22) || defined(PINGUINO2455) || defined(PINGUINO2550) || defined(PINGUINO25K50) || defined(CHRP3) || defined(PINGUINO26J50) || defined(FREEJALDUINO) || defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)
        case pC: 
                steppervalues[pC] = steppervalues[pC] | mask[pin];  // list pin as servo driver.
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)				    
        case pD: 
                steppervalues[pD] = steppervalues[pD] | mask[pin];  // list pin as servo driver.
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50)	    
        case pE: 
                steppervalues[pE] = steppervalues[pE] | mask[pin];  // list pin as servo driver.
                break;	            	            
        #endif
    }
}


void ClockDetach(unsigned char pin)
{
    if(pin>=TotalPICpins) return;

    switch (port[pin])
    {
        case pA: steppervalues[pA] = steppervalues[pA] ^ mask[pin];
                break;
        case pB: steppervalues[pB] = steppervalues[pB] ^ mask[pin];
                break;
        #if defined(__18f14k22) || defined(PINGUINO2455) || defined(PINGUINO2550) || defined(PINGUINO25K50) || defined(CHRP3) || defined(PINGUINO26J50) || defined(FREEJALDUINO) || defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)
        case pC: steppervalues[pC] = steppervalues[pC] ^ mask[pin];
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO) 
        case pD: steppervalues[pD] = steppervalues[pD] ^ mask[pin];
                break;
        #endif
        #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50)	    
        case pE: steppervalues[pE] = steppervalues[pE] ^ mask[pin];
                break;
        #endif
    }
}

stepper _newStepper(u16 motor_steps, u8 motor_dir_pin, u8 motor_enable_pin, u8 motor_clock_pin)
{
    stepper m;
    MotorsToAttach++;
    // Pinguino pins for the motor control connection
    m.DirectionPin = motor_dir_pin;
    //StepperAttach(motor_dir_pin);
    m.EnablePin = motor_enable_pin;
    m.EnablePinState = HIGH;
    //StepperAttach(motor_enable_pin);
    m.ClockPin = motor_clock_pin;
    this_clocks_pins[MotorsToAttach] = motor_clock_pin;
    ClockAttach(motor_clock_pin);
    m.MotorInUse = MotorsToAttach;
    m.Direction = 1;
    // setup the pins on the microcontroller
    pinmode(motor_dir_pin, OUTPUT, DIGITAL);
    pinmode(motor_enable_pin, OUTPUT, DIGITAL);        
    pinmode(motor_clock_pin, OUTPUT, DIGITAL);
    digitalwrite(motor_clock_pin, LOW);
    
    this_steps_per_rev = motor_steps;// total number of steps for this motor
    //this_current_step1[MotorsToAttach] = 0;              // which step the motor is on
    //this_direction1[MotorsToAttach] = 0;                 // motor direction
    this_number_of_microsteps = 1;      // full-steps per default
    this_steps_left1[MotorsToAttach] = 0;
    this_number_of_steps1[MotorsToAttach] = this_steps_per_rev * this_number_of_microsteps;
    this_number_of_steps = getMaxNumber(this_number_of_steps1);
    m.getMaxSpeed = stepper_getMaxSpeed;
    m.getMinSpeed = stepper_getMinSpeed;
    m.setSpeed = stepper_setSpeed;
    m.Step = stepper_step;
    m.DelayPerMove = delay_per_motor;
    m.DelayGroup = delay_per_group;
    //u32 pointer = &m;
    return m;
}

u32 getMaxNumber(u32 Num[])
{
    u32 Max = Num[0];
    
    for(u8 i=0; i<TotalPICpins/Pins_Per_Motor; i++)
        if(Num[i] > Max)
            Max = Num[i];
    
    return Max;
}

u8 IsZero()
{
    for(u8 i=0; i< TotalPICports; i++)
        if(steppervalues[i] != 0)
            return false;
    
    return true;
}

static void cpyArrays()//u32 *Num1, u32 *Num2)
{
    for(u8 i=0; i< TotalPICports; i++)
    {
        u8 b = activatedstepper[i];
        steppervalues[i] = activatedstepper[i];
    }
}

// This function starts up pulses for all activated servos.
static void StepperPulseToggle()
{
    PORTA = PORTA ^ steppervalues[pA];
    PORTB = PORTB ^ steppervalues[pB];
    #if defined(__18f14k22) || defined(PINGUINO2455) || defined(PINGUINO2550) || defined(PINGUINO25K50) || defined(CHRP3) || defined(PINGUINO26J50) || defined(FREEJALDUINO) || defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)
    PORTC = PORTC ^ steppervalues[pC];
    #endif
    #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50) || defined(PICUNO_EQUO)			
    PORTD = PORTD ^ steppervalues[pD];
    #endif
    #if defined(PINGUINO47J53) || defined(PINGUINO47J53B) || defined(PINGUINO4550) || defined(PINGUINO45K50)
    PORTE = PORTE ^ steppervalues[pE];
    #endif
}

void delay_per_motor(stepper *Motor)
{
    
    delay_ms_per_move1[Motor->MotorInUse] = ( this_steps_left1[Motor->MotorInUse] * this_delay_us_per_step ) / 2; // / 1000 / 2;
    delay_us_per_move1[Motor->MotorInUse] = delay_ms_per_move1[Motor->MotorInUse] - (( delay_ms_per_move1[Motor->MotorInUse] / 1000 ) * 1000);
    delay_ms_per_move1[Motor->MotorInUse] = delay_ms_per_move1[Motor->MotorInUse] / 1000;
    
    Delayms(delay_ms_per_move1[Motor->MotorInUse]);
    Delayus(delay_us_per_move1[Motor->MotorInUse]);
}

void delay_per_group()
{
    for(u8 i=0; i<TotalPICpins/Pins_Per_Motor; i++)
    {
        delay_ms_per_move1[i] = ( this_steps_left1[i] * this_delay_us_per_step ) / 2; // / 1000 / 2;
        delay_us_per_move1[i] = delay_ms_per_move1[i] - (( delay_ms_per_move1[i] / 1000 ) * 1000);
        delay_ms_per_move1[i] = delay_ms_per_move1[i] / 1000;
    }
    u32 Dms = getMaxNumber(delay_ms_per_move1);
    u32 Dus = getMaxNumber(delay_us_per_move1);
    Delayms(Dms);
    Delayus(Dus);
    //Delayus(1000);
}
#endif /* __STEPPER_H */