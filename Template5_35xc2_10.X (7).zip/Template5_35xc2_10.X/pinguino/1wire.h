#ifndef __ONEWIRE_H
#define __ONEWIRE_H

    // Standard 1-Wire timing
    // https://www.maximintegrated.com/en/app-notes/index.mvp/id/126
    #define TimeA   10      // 6
    #define TimeB   55      // 64
    #define TimeC   65      // 60
    #define TimeD   5       // 10
    #define TimeE   10      // 9
    #define TimeF   53      // 55
    #define TimeG   3       // 0
    #define TimeH   1000    // 480 min
    #define TimeI   100     // 70
    #define TimeJ   410

    // private
    /*
    void OneWireLow(u8, u16);
    void OneWireHigh(u8, u16);
    u8 OneWireRead(u8, u16);
    */
    // public
    u8 OneWireReset(u8);
    u8 OneWireReadBit(u8);
    void OneWireWriteBit(u8, u8);
    u8 OneWireReadByte(u8);
    void OneWireWriteByte(u8, u8);

#endif