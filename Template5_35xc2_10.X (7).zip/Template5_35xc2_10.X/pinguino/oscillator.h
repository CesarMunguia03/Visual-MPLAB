#ifndef __OSCILLATOR_H
#define __OSCILLATOR_H

u16 System_readFlashMemory(u32 address);
u32 System_getCpuFrequency();
void System_setExtOsc();
void System_setTimer1Osc();
void System_setIntOsc(u32 freq);
void System_setCpuFrequency(u32 freq);
void System_setPeripheralFrequency(u32 freq);

#define SystemGetInstructionClock()		System_getPeripheralFrequency()	
#define System_getPeripheralFrequency()	(System_getCpuFrequency() >> 2)

#endif /* __OSCILLATOR_H */