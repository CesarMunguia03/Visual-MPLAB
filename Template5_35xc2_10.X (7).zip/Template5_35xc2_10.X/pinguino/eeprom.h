#ifndef __EEPROM_H
	#define __EEPROM_H

//Declaracion de los prototipos de funcion
u8      EEPROM_read8(u8 address);
u16     EEPROM_read16(u8 address);
void    EEPROM_write8(u8 address, u8 mydata);
void    EEPROM_write16(u8 address, u16 mydata)
#endif