/*
 * pulseIn() function, for Pinguino 8bits
 * Port by Marcus Fazzi, anunakin@ieee.org 
 * 
 * 17/02/2011, first try
 */
 
#ifndef __PULSE_H
#define __PULSE_H

#include "typedef.h"

u16 pulseIn(u8 pin, u8 state, u16 timeout);
#endif