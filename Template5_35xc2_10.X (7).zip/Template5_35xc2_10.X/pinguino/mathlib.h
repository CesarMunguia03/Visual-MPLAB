#ifndef __MATHLIB_H
#define __MATHLIB_H

int abs(int v);
int random(int mini, int maxi);
//int map(int x, int in_min, int in_max, int out_min, int out_max);
long map(long x, long in_min, long in_max, long out_min, long out_max);

#endif