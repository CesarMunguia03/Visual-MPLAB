/*	----------------------------------------------------------------------------
    workspace.h
    Mario de Jes�s Mart�nez S�nchez
    ----------------------------------------------------------------------------
*/

#ifndef __WORKSPACE_H
#define __WORKSPACE_H

void setup();
void loop();

#endif