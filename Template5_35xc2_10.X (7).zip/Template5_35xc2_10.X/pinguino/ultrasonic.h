#ifndef __ULTRASONIC_H
#define __ULTRASONIC_H

#include "typedef.h"


//-----------------------------------------------------------------------------------------------------------------------------
// Variable definition that depends on PIC type:
//-----------------------------------------------------------------------------------------------------------------------------
#if defined(PINGUINO1220) || defined(PINGUINO1320)
#define TotalPICpins   19
#define TotalPICports   2

#elif defined(__18f14k22)
#define TotalPICpins   19
#define TotalPICports   3

#elif  defined(PINGUINO2455) || defined(PINGUINO2550) || defined(PINGUINO25K50) || defined(CHRP3)
#define TotalPICpins   19
#define TotalPICports   3

#elif defined(PINGUINO26J50)
#define TotalPICpins   18
#define TotalPICports   3

#elif defined(PINGUINO47J53)
#define TotalPICpins   32
#define TotalPICports   5

#elif defined(PINGUINO4550) || defined(PINGUINO45K50)
#define TotalPICpins   32
#define TotalPICports   5
#define Pins_Per_Motor   3

#elif defined(FREEJALDUINO)
#define TotalPICpins   19
#define TotalPICports   3

#elif defined(PICUNO_EQUO)
#define TotalPICpins   14
#define TotalPICports   4

#endif

u8 EchoPin[TotalPICports];
u8 TriggerPin[TotalPICports];
u8 UltrasonicPins[TotalPICports];

#define CM 1
#define INCH 0
    u8  Trig_pin;
    u8  Echo_pin;
    u16 Time_out;
    float duration;
    float distance_cm;
    float distance_inch;
    
    void    Ultrasonic(u8 TP, u8 EP);
	void    Ultrasonic1(u8 TP, u8 EP, u32 TO);
    u16     UltrasonicTiming(u8 EchoPin);
    //u16     UltrasonicTiming();
    //float   UltrasonicRanging(u8 sys);
    float   UltrasonicRanging(u8 EchoPin, u8 sys);
    void    UltrasonicAttach(u8 TP, u8 EP);

#endif