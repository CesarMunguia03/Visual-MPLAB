
#ifndef __SERIAL_H
#define __SERIAL_H

#include "typedef.h"

//extern u32 _cpu_clock_

// RX buffer length
#ifndef RXBUFFERLENGTH
    #if defined(__16F1459) || \
        defined(__18f1220) || defined(__18f1320) || \
        defined(__18f14k22)
        #define RXBUFFERLENGTH 64
    #else
        #define RXBUFFERLENGTH 128
    #endif
#endif

#define BaudRateDivisor(f, b)   ((f/(4*b))-1)

/***********************************************************************
 * Serial.available()
 * return true if a new character has been received, otherwise false
 **********************************************************************/

#define Serial_available()          (wpointer != rpointer)

/***********************************************************************
 * Serial.flush()
 * Clear RX buffer
 **********************************************************************/

#define Serial_flush()              { wpointer=1; rpointer=1; }
#define SERIALREAD

char rx[RXBUFFERLENGTH];            // serial buffer
u8 wpointer=1,rpointer=1;           // write and read pointer

void Serial_begin(u32 baudrate);
void serial_interrupt(void);
void Serial_putchar(u8 caractere);
u8 Serial_read();
void Serial_print(char *s);
void Serial_print1(const char *fmt,...);
void Serial_println(char *string);
void Serial_printNumber(long value, u8 base);
void Serial_printFloat(float number, u8 digits);
void Serial_printf(char *fmt, ...);
u8 Serial_getkey();
u8 * Serial_getstring();


#endif