#ifndef __DELAYS_H
#define __DELAYS_H

void delay(u16 milliseconds);
void delayMicroseconds(u16 microseconds);
void Delayms(u16 microseconds);
void Delayus(u16 microseconds);
#endif