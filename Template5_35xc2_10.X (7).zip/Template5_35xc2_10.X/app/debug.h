/************************************************************************
	debug.h

	WFF USB Generic HID Demonstration 3
    usbGenericHidCommunication reference firmware 3_0_0_0
    Copyright (C) 2011 Simon Inns

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

	Email: simon.inns@gmail.com

************************************************************************/

#ifndef DEBUG_H
#define DEBUG_H
#include "../pinguino/typedef.h"
// Microchip Application Library includes
// (expects V2.9a of the USB library from "Microchip Solutions v2011-07-14")
#include "../usb/usb.h" //"./USB/usb.h"
#include "../usb/usb_device_hid.h" //"./USB/usb_function_hid.h"

// Set the size of the debug information buffer in characters
#define DEBUGBUFFERSIZE 128
#define DEBUGBUFFERSIZE_1 64
#define DEBUGON

#define USB_available()          (usb_wpointer != usb_rpointer)
u8  usb_wpointer=1, usb_rpointer=1;           // USB write and read pointer
u8  USBcaractere;
u8  RxDataBuffer[64];
// Function prototypes
void debugInitialise(void);
void debugOut(char*);
void copyDebugToSendBuffer(uint8_t* sendDataBuffer);
u8   USB_read();
void USBprint(char*);
void USBprintInt(int);
void USBprintLong(long);
void USBprintFloat(float floatNumber);
void USBprintln(void);
// Only compile in the global debug variables if debugging is required
#if defined(DEBUGON)

	// Buffer pointers
	uint16_t debugBufferStart;
	uint16_t debugBufferEnd;
	uint16_t debugBufferLevel;
	
	// The following array is the cyclic buffer
	uint8_t debugBuffer[DEBUGBUFFERSIZE];

#endif
#endif